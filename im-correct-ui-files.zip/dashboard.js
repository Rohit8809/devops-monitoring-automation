console.log("Incident Management Dashboard loaded");

const containerTableBody = document.getElementById("container-table-body");
const totalContainersElement = document.getElementById("total-containers");
const runningContainersElement = document.getElementById("running-containers");
const stoppedContainersElement = document.getElementById("stopped-containers");
const refreshButton = document.getElementById("refresh-containers-button");
const messageBox = document.getElementById("container-message");

let containerLogsModal;

document.addEventListener("DOMContentLoaded", () => {
    const modalElement = document.getElementById("containerLogsModal");

    if (modalElement) {
        containerLogsModal = new bootstrap.Modal(modalElement);
    }

    refreshButton.addEventListener("click", loadContainers);

    loadContainers();

    // Automatically refresh container status every 15 seconds.
    window.setInterval(loadContainers, 15000);
});


function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


function showMessage(message, type = "success") {
    messageBox.className = `alert alert-${type} m-3`;
    messageBox.textContent = message;

    window.setTimeout(() => {
        messageBox.classList.add("d-none");
    }, 5000);
}


function statusBadge(status) {
    const normalizedStatus = String(status).toLowerCase();

    if (normalizedStatus === "running") {
        return '<span class="badge text-bg-success">Running</span>';
    }

    if (normalizedStatus === "exited") {
        return '<span class="badge text-bg-danger">Stopped</span>';
    }

    if (normalizedStatus === "restarting") {
        return '<span class="badge text-bg-warning">Restarting</span>';
    }

    if (normalizedStatus === "paused") {
        return '<span class="badge text-bg-secondary">Paused</span>';
    }

    return `<span class="badge text-bg-secondary">${escapeHtml(status)}</span>`;
}


function actionButtons(container) {
    const name = escapeHtml(container.name);
    const encodedName = encodeURIComponent(container.name);
    const running = container.status === "running";

    if (!container.action_allowed) {
        return `
            <button class="btn btn-sm btn-outline-secondary" disabled>
                <i class="bi bi-lock"></i>
                Protected
            </button>

            <button
                class="btn btn-sm btn-outline-dark"
                onclick="viewContainerLogs('${encodedName}', '${name}')"
            >
                <i class="bi bi-terminal"></i>
                Logs
            </button>
        `;
    }

    const startButton = `
        <button
            class="btn btn-sm btn-outline-success"
            onclick="performContainerAction('${encodedName}', 'start', '${container.protection_level}')"
            ${running ? "disabled" : ""}
        >
            <i class="bi bi-play-fill"></i>
            Start
        </button>
    `;

    const stopButton = `
        <button
            class="btn btn-sm btn-outline-danger"
            onclick="performContainerAction('${encodedName}', 'stop', '${container.protection_level}')"
            ${running ? "" : "disabled"}
        >
            <i class="bi bi-stop-fill"></i>
            Stop
        </button>
    `;

    const restartButton = `
        <button
            class="btn btn-sm btn-outline-warning"
            onclick="performContainerAction('${encodedName}', 'restart', '${container.protection_level}')"
        >
            <i class="bi bi-arrow-clockwise"></i>
            Restart
        </button>
    `;

    const logsButton = `
        <button
            class="btn btn-sm btn-outline-dark"
            onclick="viewContainerLogs('${encodedName}', '${name}')"
        >
            <i class="bi bi-terminal"></i>
            Logs
        </button>
    `;

    return `
        <div class="d-flex flex-wrap gap-1">
            ${startButton}
            ${stopButton}
            ${restartButton}
            ${logsButton}
        </div>
    `;
}


async function loadContainers() {
    refreshButton.disabled = true;
    refreshButton.innerHTML = `
        <span class="spinner-border spinner-border-sm me-1"></span>
        Refreshing
    `;

    try {
        const response = await fetch("/api/containers", {
            cache: "no-store"
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.message || "Unable to fetch containers");
        }

        totalContainersElement.textContent = result.total;
        runningContainersElement.textContent = result.running;
        stoppedContainersElement.textContent = result.total - result.running;

        if (!result.containers.length) {
            containerTableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center py-4 text-secondary">
                        No Docker containers were found.
                    </td>
                </tr>
            `;
            return;
        }

        containerTableBody.innerHTML = result.containers.map(container => `
            <tr>
                <td>
                    <div class="fw-semibold">${escapeHtml(container.name)}</div>
                </td>

                <td>
                    <span class="small text-secondary">
                        ${escapeHtml(container.image)}
                    </span>
                </td>

                <td>
                    ${statusBadge(container.status)}
                </td>

                <td>
                    <code>${escapeHtml(container.id)}</code>
                </td>

                <td>
                    ${actionButtons(container)}
                </td>
            </tr>
        `).join("");

    } catch (error) {
        console.error(error);

        containerTableBody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-4 text-danger">
                    Failed to load Docker containers: ${escapeHtml(error.message)}
                </td>
            </tr>
        `;

        showMessage(error.message, "danger");

    } finally {
        refreshButton.disabled = false;
        refreshButton.innerHTML = `
            <i class="bi bi-arrow-clockwise"></i>
            Refresh
        `;
    }
}


async function performContainerAction(
    encodedContainerName,
    action,
    protectionLevel = "normal"
) {
    const containerName = decodeURIComponent(encodedContainerName);

    let confirmationMessage =
        `Are you sure you want to ${action} ${containerName}?`;

    if (protectionLevel === "critical") {
        confirmationMessage =
            `CRITICAL SERVICE WARNING\n\n` +
            `Container: ${containerName}\n` +
            `Action: ${action.toUpperCase()}\n\n` +
            `This action may interrupt monitoring, alerting, or ticket services.\n\n` +
            `Do you want to continue?`;
    }

    const confirmed = window.confirm(confirmationMessage);

    if (!confirmed) {
        return;
    }

    try {
        showMessage(
            `${action.charAt(0).toUpperCase() + action.slice(1)} request sent for ${containerName}`,
            "info"
        );

        const response = await fetch(
            `/api/containers/${encodedContainerName}/${action}`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                }
            }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.message || "Container action failed");
        }

        showMessage(result.message, "success");

        await loadContainers();

    } catch (error) {
        console.error(error);
        showMessage(error.message, "danger");
    }
}


async function viewContainerLogs(encodedContainerName, displayName) {
    const logsOutput = document.getElementById("container-logs-output");
    const modalTitle = document.getElementById("containerLogsModalLabel");

    modalTitle.textContent = `${displayName} logs`;
    logsOutput.textContent = "Loading logs from Docker Engine...";

    containerLogsModal.show();

    try {
        const response = await fetch(
            `/api/containers/${encodedContainerName}/logs`,
            {
                cache: "no-store"
            }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.message || "Unable to retrieve logs");
        }

        logsOutput.textContent = result.logs || "No logs available.";

    } catch (error) {
        console.error(error);
        logsOutput.textContent = `Failed to load logs: ${error.message}`;
    }
}


const cpuCharts = {};


function createCpuChart(canvasId, series) {
    const canvas = document.getElementById(canvasId);

    if (!canvas) {
        return;
    }

    const labels = series.values.map(point => {
        return new Date(point.timestamp * 1000)
            .toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit"
            });
    });

    const values = series.values.map(point => point.value);

    const chartColors = {
        "db-server-cpu-chart": {
            line: "#315efb",
            fill: "rgba(49, 94, 251, 0.10)"
        },
        "monitoring-server-cpu-chart": {
            line: "#12a66a",
            fill: "rgba(18, 166, 106, 0.10)"
        },
        "node-exporter-cpu-chart": {
            line: "#8b5cf6",
            fill: "rgba(139, 92, 246, 0.10)"
        }
    };

    const colors = chartColors[canvasId] || chartColors["db-server-cpu-chart"];

    if (cpuCharts[canvasId]) {
        cpuCharts[canvasId].destroy();
    }

    cpuCharts[canvasId] = new Chart(canvas, {
        type: "line",

        data: {
            labels: labels,
            datasets: [
                {
                    label: "CPU Usage",
                    data: values,
                    borderColor: colors.line,
                    backgroundColor: colors.fill,
                    borderWidth: 2,
                    pointRadius: 0,
                    pointHoverRadius: 4,
                    tension: 0.25,
                    fill: true
                }
            ]
        },

        options: {
            responsive: true,
            maintainAspectRatio: false,

            interaction: {
                mode: "index",
                intersect: false
            },

            plugins: {
                legend: {
                    display: false
                },

                tooltip: {
                    callbacks: {
                        label: context => {
                            return `CPU: ${context.parsed.y.toFixed(2)}%`;
                        }
                    }
                }
            },

            scales: {
                x: {
                    grid: {
                        display: false
                    },

                    ticks: {
                        color: "#7b879a",
                        maxTicksLimit: 6
                    },

                    title: {
                        display: true,
                        text: "Time"
                    }
                },

                y: {
                    beginAtZero: true,
                    suggestedMax: 100,

                    grid: {
                        color: "rgba(148, 163, 184, 0.16)"
                    },

                    title: {
                        display: true,
                        text: "CPU %"
                    },

                    ticks: {
                        color: "#7b879a",
                        callback: value => `${value}%`
                    }
                }
            }
        }
    });
}


async function loadCpuGraphs() {
    const refreshCpuButton = document.getElementById(
        "refresh-cpu-button"
    );

    const graphMessage = document.getElementById(
        "cpu-graph-message"
    );

    if (!refreshCpuButton) {
        return;
    }

    refreshCpuButton.disabled = true;

    refreshCpuButton.innerHTML = `
        <span class="spinner-border spinner-border-sm me-1"></span>
        Loading
    `;

    graphMessage.classList.add("d-none");

    try {
        const response = await fetch(
            "/api/metrics/cpu-history",
            {
                cache: "no-store"
            }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || "Unable to load CPU graphs"
            );
        }

        const chartMapping = {
            "db-server:9100": "db-server-cpu-chart",
            "monitoring-server:9100": "monitoring-server-cpu-chart",
            "node-exporter:9100": "node-exporter-cpu-chart"
        };

        for (const [instance, canvasId] of Object.entries(chartMapping)) {
            const series = result.series.find(
                item => item.instance === instance
            );

            if (!series || !series.values.length) {
                console.warn(`No CPU data found for ${instance}`);
                continue;
            }

            createCpuChart(canvasId, series);
        }

    } catch (error) {
        console.error("CPU graph error:", error);

        graphMessage.textContent = error.message;
        graphMessage.classList.remove("d-none");

    } finally {
        refreshCpuButton.disabled = false;

        refreshCpuButton.innerHTML = `
            <i class="bi bi-arrow-clockwise"></i>
            Refresh Graphs
        `;
    }
}


document.addEventListener("DOMContentLoaded", () => {
    const refreshCpuButton = document.getElementById(
        "refresh-cpu-button"
    );

    if (refreshCpuButton) {
        refreshCpuButton.addEventListener(
            "click",
            loadCpuGraphs
        );
    }

    loadCpuGraphs();

    window.setInterval(loadCpuGraphs, 60000);
});


function ticketStatusBadge(status, statusState) {
    const normalizedState = String(statusState || "").toLowerCase();

    if (normalizedState === "open") {
        return `
            <span class="badge text-bg-success">
                ${escapeHtml(status)}
            </span>
        `;
    }

    if (normalizedState === "closed") {
        return `
            <span class="badge text-bg-secondary">
                ${escapeHtml(status)}
            </span>
        `;
    }

    if (normalizedState === "archived") {
        return `
            <span class="badge text-bg-dark">
                ${escapeHtml(status)}
            </span>
        `;
    }

    return `
        <span class="badge text-bg-secondary">
            ${escapeHtml(status)}
        </span>
    `;
}


function ticketPriorityBadge(priority) {
    const normalizedPriority = String(priority || "").toLowerCase();

    if (
        normalizedPriority === "emergency" ||
        normalizedPriority === "critical"
    ) {
        return `
            <span class="badge text-bg-danger">
                ${escapeHtml(priority)}
            </span>
        `;
    }

    if (normalizedPriority === "high") {
        return `
            <span class="badge text-bg-warning">
                ${escapeHtml(priority)}
            </span>
        `;
    }

    if (normalizedPriority === "low") {
        return `
            <span class="badge text-bg-info">
                ${escapeHtml(priority)}
            </span>
        `;
    }

    return `
        <span class="badge text-bg-primary">
            ${escapeHtml(priority || "Normal")}
        </span>
    `;
}


function formatTicketDate(dateValue) {
    if (!dateValue) {
        return "—";
    }

    const date = new Date(dateValue);

    if (Number.isNaN(date.getTime())) {
        return escapeHtml(dateValue);
    }

    return date.toLocaleString([], {
        year: "numeric",
        month: "short",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit"
    });
}


function showTicketMessage(message, type = "success") {
    const messageBox = document.getElementById("ticket-message");

    if (!messageBox) {
        return;
    }

    messageBox.className = `alert alert-${type} m-3`;
    messageBox.textContent = message;

    window.setTimeout(() => {
        messageBox.classList.add("d-none");
    }, 5000);
}


async function loadTicketSummary() {
    const openIncidentCount = document.getElementById(
        "open-incidents-count"
    );

    if (!openIncidentCount) {
        return;
    }

    try {
        const response = await fetch(
            "/api/tickets/summary",
            {
                cache: "no-store"
            }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || "Unable to load incident summary"
            );
        }

        openIncidentCount.textContent = result.open;

    } catch (error) {
        console.error("Ticket summary error:", error);
        openIncidentCount.textContent = "—";
    }
}


async function loadTickets() {
    const tableBody = document.getElementById("ticket-table-body");
    const refreshButton = document.getElementById(
        "refresh-tickets-button"
    );

    if (!tableBody || !refreshButton) {
        return;
    }

    refreshButton.disabled = true;
    refreshButton.innerHTML = `
        <span class="spinner-border spinner-border-sm me-1"></span>
        Loading
    `;

    try {
        const response = await fetch(
            "/api/tickets?limit=10",
            {
                cache: "no-store"
            }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || "Unable to retrieve osTicket incidents"
            );
        }

        if (!result.tickets.length) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center py-4 text-secondary">
                        No osTicket incidents were found.
                    </td>
                </tr>
            `;

            await loadTicketSummary();
            return;
        }

        tableBody.innerHTML = result.tickets.map(ticket => `
            <tr>
                <td>
                    <div class="fw-semibold">
                        ${escapeHtml(ticket.number)}
                    </div>

                    <small class="text-secondary">
                        ID ${escapeHtml(ticket.ticket_id)}
                    </small>
                </td>

                <td>
                    <div class="ticket-subject">
                        ${escapeHtml(ticket.subject)}
                    </div>

                    <small class="text-secondary">
                        ${escapeHtml(ticket.requester_email)}
                    </small>
                </td>

                <td>
                    ${ticketPriorityBadge(ticket.priority)}
                </td>

                <td>
                    ${ticketStatusBadge(
                        ticket.status,
                        ticket.status_state
                    )}
                </td>

                <td>
                    ${escapeHtml(ticket.department)}
                </td>

                <td>
                    <span class="small">
                        ${formatTicketDate(ticket.created)}
                    </span>
                </td>

                <td>
                    <a
                        href="http://localhost:8080/scp/tickets.php?id=${encodeURIComponent(ticket.ticket_id)}"
                        target="_blank"
                        rel="noopener noreferrer"
                        class="btn btn-sm btn-outline-dark"
                    >
                        <i class="bi bi-box-arrow-up-right"></i>
                        View
                    </a>
                </td>
            </tr>
        `).join("");

        await loadTicketSummary();

    } catch (error) {
        console.error("Ticket loading error:", error);

        tableBody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center py-4 text-danger">
                    Failed to load incidents: ${escapeHtml(error.message)}
                </td>
            </tr>
        `;

        showTicketMessage(error.message, "danger");

    } finally {
        refreshButton.disabled = false;
        refreshButton.innerHTML = `
            <i class="bi bi-arrow-clockwise"></i>
            Refresh Tickets
        `;
    }
}


document.addEventListener("DOMContentLoaded", () => {
    const refreshTicketsButton = document.getElementById(
        "refresh-tickets-button"
    );

    if (refreshTicketsButton) {
        refreshTicketsButton.addEventListener(
            "click",
            loadTickets
        );
    }

    loadTickets();
    loadTicketSummary();

    // Refresh incidents automatically every 30 seconds.
    window.setInterval(loadTickets, 30000);
});


function formatAlertTime(dateValue) {
    if (!dateValue) {
        return "Unknown";
    }

    const date = new Date(dateValue);

    if (Number.isNaN(date.getTime())) {
        return escapeHtml(dateValue);
    }

    return date.toLocaleString([], {
        month: "short",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit"
    });
}


function alertSeverityClass(severity) {
    const normalizedSeverity = String(severity || "").toLowerCase();

    if (normalizedSeverity === "critical") {
        return "danger";
    }

    if (
        normalizedSeverity === "warning" ||
        normalizedSeverity === "warn"
    ) {
        return "warning";
    }

    return "secondary";
}


function updateAlertIndicator(summary) {
    const button = document.getElementById("alert-indicator-button");
    const icon = document.getElementById("alert-indicator-icon");
    const countBadge = document.getElementById("active-alert-count");

    if (!button || !icon || !countBadge) {
        return;
    }

    button.classList.remove(
        "alert-indicator-healthy",
        "alert-indicator-warning",
        "alert-indicator-critical",
        "alert-indicator-unknown"
    );

    if (summary.critical > 0) {
        button.classList.add("alert-indicator-critical");
        icon.className = "bi bi-exclamation-octagon-fill";
        button.title = `${summary.critical} critical alert(s)`;

    } else if (summary.warning > 0) {
        button.classList.add("alert-indicator-warning");
        icon.className = "bi bi-exclamation-triangle-fill";
        button.title = `${summary.warning} warning alert(s)`;

    } else if (summary.active > 0) {
        button.classList.add("alert-indicator-warning");
        icon.className = "bi bi-bell-fill";
        button.title = `${summary.active} active alert(s)`;

    } else {
        button.classList.add("alert-indicator-healthy");
        icon.className = "bi bi-check-circle-fill";
        button.title = "No active alerts";
    }

    countBadge.textContent = summary.active;

    if (summary.active > 0) {
        countBadge.classList.remove("d-none");
    } else {
        countBadge.classList.add("d-none");
    }
}


async function loadAlertSummary() {
    try {
        const response = await fetch(
            "/api/alerts/summary",
            {
                cache: "no-store"
            }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || "Unable to load alert summary"
            );
        }

        updateAlertIndicator(result);

    } catch (error) {
        console.error("Alert summary error:", error);

        const button = document.getElementById(
            "alert-indicator-button"
        );

        const icon = document.getElementById(
            "alert-indicator-icon"
        );

        if (button && icon) {
            button.className =
                "alert-indicator alert-indicator-unknown";

            icon.className = "bi bi-question-circle-fill";
            button.title = "Alertmanager unavailable";
        }
    }
}


function renderActiveAlerts(alerts) {
    const popupContent = document.getElementById(
        "active-alerts-popup-content"
    );

    const summaryText = document.getElementById(
        "active-alert-summary"
    );

    if (!popupContent || !summaryText) {
        return;
    }

    if (!alerts.length) {
        summaryText.textContent = "0 active alerts";

        popupContent.innerHTML = `
            <div class="alert-popup-healthy">
                <i class="bi bi-check-circle-fill"></i>

                <h5>No active alerts</h5>

                <p class="mb-0 text-secondary">
                    Alertmanager reports that the monitored
                    infrastructure is healthy.
                </p>
            </div>
        `;

        return;
    }

    const criticalCount = alerts.filter(alert =>
        String(alert.severity).toLowerCase() === "critical"
    ).length;

    const warningCount = alerts.filter(alert =>
        ["warning", "warn"].includes(
            String(alert.severity).toLowerCase()
        )
    ).length;

    summaryText.textContent =
        `${alerts.length} active · ` +
        `${criticalCount} critical · ` +
        `${warningCount} warning`;

    popupContent.innerHTML = alerts.map(alert => {
        const severityClass = alertSeverityClass(
            alert.severity
        );

        return `
            <div class="active-alert-item border-${severityClass}">
                <div class="d-flex justify-content-between gap-3">
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <span
                                class="badge text-bg-${severityClass}"
                            >
                                ${escapeHtml(
                                    String(alert.severity).toUpperCase()
                                )}
                            </span>

                            <span class="fw-semibold">
                                ${escapeHtml(alert.alertname)}
                            </span>
                        </div>

                        <div class="small text-secondary mb-2">
                            ${escapeHtml(alert.instance)}
                        </div>

                        <div>
                            ${escapeHtml(alert.summary)}
                        </div>
                    </div>

                    <div class="small text-secondary text-nowrap">
                        ${formatAlertTime(alert.starts_at)}
                    </div>
                </div>
            </div>
        `;
    }).join("");
}


async function loadActiveAlerts() {
    const popupContent = document.getElementById(
        "active-alerts-popup-content"
    );

    const refreshButton = document.getElementById(
        "refresh-alerts-button"
    );

    if (!popupContent) {
        return;
    }

    if (refreshButton) {
        refreshButton.disabled = true;
        refreshButton.innerHTML = `
            <span class="spinner-border spinner-border-sm me-1"></span>
            Loading
        `;
    }

    try {
        const response = await fetch(
            "/api/alerts",
            {
                cache: "no-store"
            }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || "Unable to retrieve alerts"
            );
        }

        renderActiveAlerts(result.alerts);
        await loadAlertSummary();

    } catch (error) {
        console.error("Active-alert loading error:", error);

        popupContent.innerHTML = `
            <div class="alert alert-danger mb-0">
                ${escapeHtml(error.message)}
            </div>
        `;

    } finally {
        if (refreshButton) {
            refreshButton.disabled = false;
            refreshButton.innerHTML = `
                <i class="bi bi-arrow-clockwise"></i>
                Refresh
            `;
        }
    }
}


document.addEventListener("DOMContentLoaded", () => {
    const alertButton = document.getElementById(
        "alert-indicator-button"
    );

    const refreshAlertsButton = document.getElementById(
        "refresh-alerts-button"
    );

    if (alertButton) {
        alertButton.addEventListener(
            "click",
            loadActiveAlerts
        );
    }

    if (refreshAlertsButton) {
        refreshAlertsButton.addEventListener(
            "click",
            loadActiveAlerts
        );
    }

    loadAlertSummary();

    // Update the top-right indicator every 15 seconds.
    window.setInterval(loadAlertSummary, 15000);
});


/* =========================================================
   LIVE INFRASTRUCTURE SERVERS
   ========================================================= */

function formatServerCheckTime(value) {
    if (!value) {
        return "Not available";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return value;
    }

    return date.toLocaleString();
}


function serverStatusDetails(status) {
    const normalizedStatus = String(status).toLowerCase();

    if (normalizedStatus === "online") {
        return {
            badgeClass: "text-bg-success",
            cardClass: "server-card-online",
            indicatorClass: "server-status-online",
            icon: "check-circle-fill",
            label: "Online"
        };
    }

    if (normalizedStatus === "offline") {
        return {
            badgeClass: "text-bg-danger",
            cardClass: "server-card-offline",
            indicatorClass: "server-status-offline",
            icon: "x-circle-fill",
            label: "Offline"
        };
    }

    return {
        badgeClass: "text-bg-warning",
        cardClass: "server-card-unknown",
        indicatorClass: "server-status-unknown",
        icon: "question-circle-fill",
        label: "Unknown"
    };
}


function renderServerCards(servers) {
    const container = document.getElementById(
        "server-cards-container"
    );

    if (!container) {
        return;
    }

    if (!servers.length) {
        container.innerHTML = `
            <div class="col-12">
                <div class="alert alert-warning mb-0">
                    No Prometheus server targets were returned.
                </div>
            </div>
        `;
        return;
    }

    container.innerHTML = servers.map((server) => {
        const status = serverStatusDetails(server.status);

        const responseTime = server.response_time_ms === null
            ? "Not available"
            : `${escapeHtml(server.response_time_ms)} ms`;

        const errorContent = server.error
            ? `
                <div class="server-error mt-3">
                    <i class="bi bi-exclamation-triangle me-1"></i>
                    ${escapeHtml(server.error)}
                </div>
            `
            : "";

        return `
            <div class="col-12 col-md-6 col-xl-3">
                <div class="server-card ${status.cardClass}">
                    <div class="d-flex justify-content-between align-items-start">
                        <div class="server-icon">
                            <i class="bi bi-${escapeHtml(server.icon)}"></i>
                        </div>

                        <span class="badge ${status.badgeClass}">
                            ${status.label}
                        </span>
                    </div>

                    <div class="mt-3">
                        <div class="d-flex align-items-center gap-2">
                            <span class="server-status-dot ${status.indicatorClass}"></span>
                            <h5 class="mb-0">
                                ${escapeHtml(server.name)}
                            </h5>
                        </div>

                        <p class="text-secondary small mb-3 mt-1">
                            ${escapeHtml(server.role)}
                        </p>
                    </div>

                    <div class="server-detail">
                        <span>Target</span>
                        <strong title="${escapeHtml(server.instance)}">
                            ${escapeHtml(server.instance)}
                        </strong>
                    </div>

                    <div class="server-detail">
                        <span>Prometheus job</span>
                        <strong>${escapeHtml(server.job)}</strong>
                    </div>

                    <div class="server-detail">
                        <span>Response time</span>
                        <strong>${responseTime}</strong>
                    </div>

                    <div class="server-detail">
                        <span>Last checked</span>
                        <strong>
                            ${escapeHtml(
                                formatServerCheckTime(server.last_check)
                            )}
                        </strong>
                    </div>

                    ${errorContent}
                </div>
            </div>
        `;
    }).join("");
}


async function loadServers() {
    const container = document.getElementById(
        "server-cards-container"
    );

    const message = document.getElementById(
        "server-message"
    );

    const refreshButton = document.getElementById(
        "refresh-servers-button"
    );

    if (!container) {
        return;
    }

    if (refreshButton) {
        refreshButton.disabled = true;
        refreshButton.innerHTML = `
            <span class="spinner-border spinner-border-sm me-1"></span>
            Refreshing
        `;
    }

    if (message) {
        message.classList.add("d-none");
    }

    try {
        const response = await fetch(
            "/api/servers",
            {
                cache: "no-store"
            }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || "Unable to retrieve servers"
            );
        }

        document.getElementById(
            "total-servers-count"
        ).textContent = result.summary.total;

        document.getElementById(
            "online-servers-count"
        ).textContent = result.summary.online;

        document.getElementById(
            "offline-servers-count"
        ).textContent = result.summary.offline;

        renderServerCards(result.servers);

    } catch (error) {
        console.error("Server loading error:", error);

        container.innerHTML = "";

        if (message) {
            message.textContent = error.message;
            message.classList.remove("d-none");
        }

    } finally {
        if (refreshButton) {
            refreshButton.disabled = false;
            refreshButton.innerHTML = `
                <i class="bi bi-arrow-clockwise"></i>
                Refresh Servers
            `;
        }
    }
}


document.addEventListener("DOMContentLoaded", () => {
    const refreshServersButton = document.getElementById(
        "refresh-servers-button"
    );

    if (refreshServersButton) {
        refreshServersButton.addEventListener(
            "click",
            loadServers
        );
    }

    loadServers();

    // Prometheus evaluates and scrapes every 15 seconds.
    window.setInterval(loadServers, 15000);
});


/* =========================================================
   LIVE END-TO-END INCIDENT WORKFLOW
   ========================================================= */

function flowStatusDetails(status) {
    const normalized = String(status || "unknown").toLowerCase();
    const details = {
        healthy: { label: "Healthy", icon: "check-circle-fill" },
        warning: { label: "Warning", icon: "exclamation-triangle-fill" },
        critical: { label: "Down", icon: "x-circle-fill" },
        unknown: { label: "Unknown", icon: "question-circle-fill" }
    };

    return details[normalized] || details.unknown;
}

function flowConnectionStatus(currentStatus, nextStatus) {
    if (currentStatus === "critical" || nextStatus === "critical") {
        return "critical";
    }
    if (currentStatus === "warning" || nextStatus === "warning") {
        return "warning";
    }
    return "healthy";
}

function renderSystemFlow(components) {
    const flow = document.getElementById("system-flow");
    if (!flow) return;

    flow.innerHTML = components.map((component, index) => {
        const status = String(component.status || "unknown").toLowerCase();
        const statusDetails = flowStatusDetails(status);
        const next = components[index + 1];
        const connectionStatus = next
            ? flowConnectionStatus(status, String(next.status).toLowerCase())
            : null;

        const connector = next ? `
            <div class="flow-connector flow-connector-${connectionStatus}">
                <span class="flow-line"></span>
                <i class="bi bi-chevron-right"></i>
            </div>
        ` : "";

        return `
            <div class="flow-stage-group">
                <article class="flow-node flow-node-${status}" title="${escapeHtml(component.message)}">
                    <div class="flow-node-top">
                        <span class="flow-node-icon"><i class="bi bi-${escapeHtml(component.icon)}"></i></span>
                        <span class="flow-node-state">
                            <i class="bi bi-${statusDetails.icon}"></i>
                            ${statusDetails.label}
                        </span>
                    </div>
                    <h6>${escapeHtml(component.name)}</h6>
                    <p>${escapeHtml(component.detail)}</p>
                    <small>${escapeHtml(component.message)}</small>
                </article>
                ${connector}
            </div>
        `;
    }).join("");
}

async function loadSystemFlow() {
    const message = document.getElementById("system-flow-message");
    const overall = document.getElementById("system-flow-overall");
    const refreshButton = document.getElementById("refresh-system-flow-button");

    if (refreshButton) refreshButton.disabled = true;
    if (message) message.classList.add("d-none");

    try {
        const response = await fetch("/api/system-flow", { cache: "no-store" });
        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.message || "Unable to load workflow health");
        }

        renderSystemFlow(result.components);

        if (overall) {
            const status = String(result.overall_status || "unknown").toLowerCase();
            const details = flowStatusDetails(status);
            overall.className = `flow-overall flow-status-${status}`;
            overall.innerHTML = `<i class="bi bi-${details.icon}"></i> ${details.label}`;
            overall.title = `Last checked: ${new Date(result.checked_at).toLocaleString()}`;
        }
    } catch (error) {
        if (message) {
            message.textContent = error.message;
            message.classList.remove("d-none");
        }
        if (overall) {
            overall.className = "flow-overall flow-status-critical";
            overall.innerHTML = '<i class="bi bi-x-circle-fill"></i> Unavailable';
        }
    } finally {
        if (refreshButton) refreshButton.disabled = false;
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const refreshButton = document.getElementById("refresh-system-flow-button");
    if (refreshButton) refreshButton.addEventListener("click", loadSystemFlow);

    loadSystemFlow();
    window.setInterval(loadSystemFlow, 15000);
});
